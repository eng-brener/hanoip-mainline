# Device safety

The user forbids flashing or writing any phone partition. Preserve this rule
throughout this project, including later sessions.

- Never use fastboot flash/erase/format/update, change the active slot, write
  /dev/block devices, repair phone filesystems, or push files onto partitions.
- Do not execute historical flashing examples in README.md or docs/.
- Read-only ADB collection and local source/build/artifact changes are allowed.
- Volatile tests with `fastboot boot` have been authorized and used in this
  session. Keep diagnostic root filesystems in RAM, without automounting disks.
- Keep known-good images and hashes before preparing another variant.

# Current baseline

The 2026-10-24 USB-shell checkpoint boots Linux 7.1.0-sm7150 through a volatile
U-Boot with fastboot flashing disabled. It includes the QUP interconnect fix
from upstream PR 66. The validated v2 images and serial logs are under
work/hanoip-build-20261024/v2/.

The later UFS read-only checkpoint is under
work/hanoip-ufs-modules-20261024/iommu/. Six disks and 78 partitions were
enumerated, all 84 block devices were marked read-only, and three 64 KiB
reads matched Android. The working effective DT must retain
`iommus = <&apps_smmu 0x300 0x0>` for UFS. Removing it causes NOP OUT timeouts
with the current strict SMMU configuration. See
docs/kernel/checkpoint-2026-10-24-ufs-leitura.txt.

The BusyBox supplied by the old ramdisk is Android-specific: its reboot applet
calls setprop, which is absent in this initramfs. Do not assume that applet
actually restarted the device; verify USB/ADB state after a reset request.
The UFS diagnostic ramdisk includes a separate /sbin/reboot script which
checks for RAM-only mounts and uses SysRq. It returns to the Motorola
bootloader; normal `fastboot reboot` returned to Android in this session.

# Display experiment, 2026-10-24

The newest display pair is under work/hanoip-display-20261024/no-reset/:
u-boot-hanoip-display-noreset.img and kernel-hanoip-display-noreset.img.
Both are volatile only; UFS/SD stay disabled. Manual module loading created
card0-DSI-1 connected/enabled, active 1080x2460 at 60 Hz with two DSC blocks,
and fb0 named msmdrmfb. Visual confirmation is still pending. Touch/GPU have
not been validated. Do not replace the known-good USB/UFS images.

Keep qcom,sm7150-mdss in qcom_smmu_client_of_match: its initial identity
domain prevents framebuffer SMMU faults before DRM handoff. Do not remove
the working UFS iommus property or globally weaken IOMMU settings.

The display clock driver's GDSC must be registered. However, asserting the
MDSS core BCR reset rebooted the board before reset release, as recorded in
trace/msm-registration.txt. Only the display diagnostic DTs omit &mdss resets;
the normal DTS and panel reset-gpios were not changed for that workaround.
Earlier display images with MDSS core reset are failed variants. See
docs/kernel/checkpoint-2026-10-24-display.txt for evidence and limitations.

/sbin/reboot can return directly to Android or to Motorola fastboot. Detect
USB/ADB state after reset; do not assume which one will appear.
