# Handoff — Moto G60 hanoip mainline

Atualizado em 24/10/2026. O usuário pediu este arquivo para outra IA continuar
mais tarde. **Não iniciar novos testes automaticamente por causa deste arquivo.**

Workspace: `/Volumes/SSDExterno/Users/brener/developer/hanoip-mainline`.
Leia também `AGENTS.md`, que preserva a regra de segurança entre sessões.

## Regra absoluta do usuário

**Não dar flash em nada e não gravar nenhuma partição do celular.**
O usuário perdeu dados/drivers de uma partição em uma tentativa anterior.

- Proibidos flash, erase, format, update, troca de slot, gravação em dispositivos
  de bloco, reparos de filesystem e envio de arquivos a filesystems persistentes.
- Não executar os exemplos antigos de flash dos READMEs/documentação de agosto.
- Permitidos: fontes/builds/arquivos no computador, consultas ADB com root em
  somente leitura e testes voláteis com `fastboot boot`, já autorizados.
- O initramfs de teste fica em RAM. Nenhuma partição é montada, inclusive UFS.
- Carregar módulos e firmware na RAM interna do touch é parte do teste volátil.
  O novo driver não implementa programação de flash do controlador.
- Preservar imagens conhecidas e seus hashes; criar outra pasta para cada variante.

## Onde efetivamente paramos

1. **O display funcionou visualmente.** O usuário confirmou que a mensagem
   enviada ao console apareceu na tela no checkpoint anterior.
2. Criamos um driver mínimo para o **touch Ilitek ILI7807 por SPI**. Ele identificou
   o PID, carregou/verificou os três blocos de firmware em IRAM e registrou input.
3. **Toques físicos ainda NÃO foram validados.** Uma captura de 35 segundos
   terminou sem eventos; estatísticas `irqs=0 reports=0 rejected=0`. Não houve
   confirmação explícita de que o usuário realizou os gestos nessa janela.
4. Nesse novo boot, o display teve falhas SMMU durante a passagem do framebuffer
   ABL para o domínio DMA do DRM. O usuário relatou: **“a tela ta preta aqui”**.
5. Preparamos uma correção específica para preservar o mapeamento do framebuffer
   antigo durante essa transição. **Compilou com modpost estrito, mas NÃO foi
   empacotada em novas imagens nem testada no aparelho.**
6. O usuário pediu o handoff antes desse próximo boot. Não continuamos os testes.

### Estado do aparelho no encerramento

- Último estado consultado por shell: Linux temporário, display preto, touch
  inicializado, contadores zero, apenas `ram0` a `ram15`, mounts em RAM/pseudo.
- **Na última checagem do host, não apareceu nenhum aparelho em ADB, fastboot ou
  `/dev/cu.usbmodem*`. A causa não foi determinada.** Pode ter mudado de estado ou
  sido desconectado; não assumir que continua no Linux ou que voltou ao Android.
- Nenhuma nova reinicialização foi solicitada após o pedido deste arquivo.

## Hardware e acesso

- Moto G60, `hanoip`, XT2135-1, Qualcomm SM7150/732G.
- Serial Android/ABL fastboot: `ZF523QJBSG`.
- Android tem root: `adb ... exec-out su -c 'COMANDO_SOMENTE_LEITURA'`.
- Kernel Android: `4.14.206—CosmicFresh-R6-Final`.
- Slot observado: `_a`. Não alterá-lo.
- Linux de diagnóstico: `7.1.0-sm7150`; última imagem do touch mostrou build `#7`.
- USB ACM Linux costuma ser `/dev/cu.usbmodem211401`, mas descobrir novamente.
- U-Boot volátil pode anunciar serial `????????????`. Não usar essa string em
  `fastboot -s`: já causou espera. Confirmar um único aparelho e consultar
  `fastboot getvar product`, esperando `motorola-hanoip`, antes do boot do kernel.
- Cada `fastboot boot` do U-Boot demora cerca de 10,4 s. Linux abre USB em ~7–20 s.
- O DT efetivo entregue ao Linux é o **DT embutido no U-Boot**, não apenas o DTB
  empacotado em `boot.img`. Alterações de DT precisam chegar às duas árvores.

## Checkpoints preservados

### USB e UFS em leitura

- `work/hanoip-build-20261024/v2/`: par sem UFS com shell USB validado.
- `work/hanoip-ufs-modules-20261024/iommu/`: par UFS validado em leitura.
  Seis discos, 78 partições, todos os 84 block devices marcados somente leitura.
  Três leituras de 64 KiB de `/dev/sdb` deram o mesmo SHA e conferiram com Android.
- Manter `iommus = <&apps_smmu 0x300 0x0>` na UFS: sem isso, houve NOP OUT timeout
  com a configuração SMMU strict. Não remover nem usar passthrough global.
- Documentação: `docs/kernel/checkpoint-2026-10-24-ufs-leitura.txt`.
- Originais preservados em `work/baseline-before-qup-2026-10-24/`.

### Display confirmado pelo usuário

Par em `work/hanoip-display-20261024/no-reset/`:

- `u-boot-hanoip-display-noreset.img`
- `kernel-hanoip-display-noreset.img`

O usuário disse **“apreceu a mensagem na tela pode seguir”**. Logs comprovaram:
`card0-DSI-1` connected/enabled, CRTC ativo 1080×2460 a 60 Hz, pixel clock
343458 kHz, dois DSC, `fb0=msmdrmfb`, pitch 4352. GPU desabilitada nesse teste.
Isso valida aquele boot, não estabilidade de todos os handoffs.

Fontes/ajustes dessa etapa:

- Painel Tianma ILI7807S: reset elétrico alto 4 ms, baixo 1 ms, alto 12 ms,
  traduzido para GPIO_ACTIVE_LOW; VFP 2565, VBP 12, VPW 2.
- DSC 1.1, slices 540×10, duas por pacote, 8 bpc/8 bpp, block prediction;
  PPS após a sequência vendor. Backport upstream da flag
  `MIPI_DSI_MODE_DSC_ALL_SLICES_IN_PKT`, não do campo experimental da PR69.
- WLED strings 0/1/2 (stock bitmask 7), brilho inicial 512/4095,
  25000 µA por string, boost 1400 mA, OVP 26500 mV.
- `qcom,sm7150-mdss` adicionado a `qcom_smmu_client_of_match` em
  `drivers/iommu/arm/arm-smmu/arm-smmu-qcom.c`. Mantém domínio identity inicial
  como em outros SoCs, necessário antes de o DRM assumir o display.
- DISPCC definia `mdss_gdsc`, mas não o registrava: restauramos `.gdscs` e
  `.num_gdscs` em `drivers/clk/qcom/dispcc-sm7150.c`.
- O reset BCR do core MDSS reiniciou o aparelho. Logs instrumentados em
  `work/hanoip-display-20261024/trace/msm-registration.txt` terminaram em
  `HANOIP MDSS: asserting reset`, sem `reset released`.
  Só os DTs de diagnóstico omitem `&mdss` `resets`. O reset GPIO do painel
  continua presente. Não reintroduzir esse BCR sem investigar.
- Fontes mantêm a configuração PLL/clocks herdada do ABL. Ainda não restauramos
  todo o init de PLL/gating do DISPCC upstream.
- `docs/kernel/checkpoint-2026-10-24-display.txt` contém detalhes e limites.

## Touch: o que foi feito e o que falta

### Referência e firmware original

Fontes públicos de referência:
`Dark-Matter7232/CosmicFresh-Hanoip`, commit
`9eecac9f6efd66fd2915fd80dd822d690ecbc207`, diretório
`drivers/input/touchscreen/ilitek_v3_mmi/`.
Cópias/proveniência estão em `work/hanoip-touch-20261024/vendor/` e
`provenance.json`. Não importamos integralmente o driver Android com seus
notificadores antigos, interfaces de fábrica, dumps e possíveis efeitos.

Coleta SOMENTE LEITURA do Android:

- `/proc/ilitek/ver_info`: chip `7807`, FW `16.0.10.0`, core `1.4.6.8`,
  protocolo `5.6.0`, driver `3.0.4.0.200731`.
- `getevent -lp`: 10 slots, X 0..1079, Y 0..2459, INPUT_PROP_DIRECT.
- `/vendor/firmware/FW_ILITEK_TDDI_TM.bin` copiado apenas para o computador.
  358761 bytes, SHA256
  `2be3ce9836bfe1ff90a32ad7b081389c0126cac47a0b058c8ecf3446248335e7`.
  Apesar da extensão, é Intel HEX, com checksums válidos.

`scripts/hanoip_ilitek_firmware.py` valida HEX, cobertura, CRC dos blocos e
identidade/layout específicos do hanoip. Gera um container local com AP,
DATA e TUNING; exclui MP/fábrica. Não faz operações no aparelho.

`work/hanoip-touch-20261024/hanoip-7807-iram.bin`: 90724 bytes, SHA256
`ef3e38c1e9dda6700ec29d09e7ec7f7c957b269ad6a56027c4ffb527051c314f`.

| Bloco | Destino IRAM | Bytes | CRC |
|---|---:|---:|---|
| AP | 0x00000 | 81920 | 0xfea9bcbd |
| DATA | 0x20870 | 8192 | 0xca3e7527 |
| TUNING | 0x20670 | 512 | 0x94d9c4dd |

### Driver novo

`kernel-mainline/drivers/input/touchscreen/ilitek-hanoip-spi.c`

- Kconfig `CONFIG_TOUCHSCREEN_HANOIP_ILITEK_SPI=m`;
  `configs/hanoip-touch.fragment`. O driver Ilitek I²C antigo não serve.
- SPI6 em 0xa80000, modo 0, até 10 MHz conforme driver stock;
  reset TLMM8, IRQ TLMM9 falling edge. O DT stock dizia level-low, mas o
  driver Android forçava falling; a variante de DT nova representa isso.
- Valida o container antes do reset. Só aceita os endereços/tamanhos coletados.
- SPI ICE → PID → carga IRAM → releitura de todos os bytes → code reset →
  verificação da versão rodando → formato demo → input com 10 slots.
- Sem comandos de apagar/programar flash do touch, sem gravações de arquivos,
  sem interfaces de fábrica, sem recovery automático ou suspend/gestures.
- Pacotes demo 0x5a/43 bytes, checksum, limites e escala 2048→1080/2460.
- Estatística somente leitura: `/sys/bus/spi/devices/spi6.0/stats`.
- `scripts/hanoip-load-touch.sh`: guard RAM-only/sem discos, carrega evdev e
  touch manualmente; `/sbin/load-touch` no initramfs.

### Evidência no hardware

Primeiro par do touch em `work/hanoip-touch-20261024/`:
`u-boot-hanoip-touch.img` + `kernel-hanoip-touch.img`.
**Não promovê-lo a display validado: teve tela preta neste boot.**

`touch-load.txt` comprovou:

```text
Ilitek PID 0x78071c03
IRAM block 1: 81920 bytes verified at 0x0
IRAM block 2: 8192 bytes verified at 0x20870
IRAM block 3: 512 bytes verified at 0x20670
FW response 21 10 00 0a 00 10 00 02 00
input: Hanoip Ilitek ILI7807 SPI ... input3
ILI7807 ready: 1080x2460, 10 slots, IRAM only
```

Registrou `/dev/input/event3`. IRQ 160, TLMM9, Edge, `spi6.0`.
`input-events.txt` capturou 35 s sem eventos. `before-handoff-retest.txt`
confirmou `irqs=0 reports=0 rejected=0`, apenas RAM e nenhum mount persistente.
Não afirmar que touch está funcional: falta gesto físico confirmado e eventos.
Também é possível que o touch TDDI dependa do painel ativo; estabilizar display
antes de concluir que o IRQ/driver está errado.

## Bug de memória/display em investigação AGORA

O domínio inicial identity resolveu o boot, mas falta preservar o framebuffer
antigo quando o DRM cria/anexa seu domínio paginado próprio.

Neste boot, durante o handoff, apareceram leituras SMMU sem mapeamento em
`0x9c...`, SIDs `0x800`/`0xc40`, depois erros DSI status=4 e
`wait for video done timed out`. O DRM criou `msmdrmfb`, mas a tela ficou preta.
**Esses erros ocorreram em uptime ~753 s; o touch só começou em ~772 s.**
Portanto não atribuir esses erros à carga do touch.

### Correção já escrita/compilada, AINDA NÃO BOOTADA

Fontes alterados:

- `msm_iommu.c`: antes de `iommu_attach_device`, para a combinação específica
  `motorola,hanoip` + `qcom,sm7150-mdss`, lê `memory-region` e mapeia o range
  reservado de splash com identidade e permissão IOMMU_READ.
  Rejeita ranges diferentes de `0x9c000000`, tamanho `0x01700000`.
- `msm_mmu.h`: guarda `firmware_start`, inicializado a zero.
- `msm_kms.c`: limita as alocações virtuais do display à região abaixo desse
  mapeamento para não haver colisão de IOVA. **Isso não diminui a RAM física.**
- DTs de display diagnóstico, nas duas árvores: `memory-region = <&cont_splash_mem>`.
  A reserva física em si não foi ampliada nem mudada.

É uma correção experimental específica do port, não uma solução upstream genérica.
Ainda é necessário verificar no hardware: sucesso do mapeamento antes do attach,
ausência de novas falhas SMMU/DSI, modeset e confirmação visual.
O `msm.ko` antigo dentro das imagens atuais NÃO contém essa correção.

Artefatos compilados preservados em:

`work/hanoip-touch-20261024/handoff-unbooted/`

- `msm.ko`: módulo novo com a correção.
- `kernel.dtb`: DT novo do touch, herdando `memory-region`.
- `u-boot.bin` e `uboot.dtb`: U-Boot/DT novos.
- `kernel-module-build.log`, `uboot-build.log`: builds concluídos sem erro.
- `source-overlay.tar.gz`, `source-manifest.json`, `source-changes.patch`, `SHA256SUMS`.
- Ainda NÃO há um par `.img` novo empacotado nessa pasta.

## Próxima sequência recomendada

1. Ler este arquivo/AGENTS e consultar o estado real de USB/ADB/fastboot.
2. Preservar os checkpoints. Não sobrescrever as imagens existentes.
3. Revisar a correção experimental de handoff e validar o novo DT com o script
   de memória. As proteções LCDB, SMMU inicial e ausência do BCR devem continuar.
4. Empacotar um par novo com os artefatos de `handoff-unbooted/`, substituindo
   também o `msm.ko` do ramdisk. Usar `Image.gz` do primeiro teste do touch:
   as alterações novas são em módulo/DT, não no Image builtin.
5. Bootar apenas em RAM. Confirmar shell/mounts/ausência de discos.
6. Carregar display, aguardar o loader terminar e coletar dmesg completo.
   Não basta esperar 5 s: o probe demora ~10 s pelos logs/earlycon.
7. Confirmar que a imagem voltou e que não existem falhas do framebuffer antigo.
8. Carregar touch, conferir IRAM/FW/input/stats. Capturar gestos com usuário
   avisado e confirmar coordenadas, press/release e eventualmente dois dedos.
9. Somente depois considerar recovery/suspend/gestures ou interface gráfica.
   GPU, rede, rootfs e instalação persistente não foram tratados nesta etapa.

### Empacotamento local sugerido — não executado ainda

Executar da raiz do projeto. Esses comandos só gravam arquivos no computador.
O empacotador recusa sobrescrever uma saída com conteúdo diferente.

```sh
python3 scripts/hanoip_boot.py ramdisk \
  work/hanoip-touch-20261024/ramdisk.cpio.gz \
  scripts/hanoip-usb-shell.init \
  work/hanoip-touch-20261024/handoff-unbooted/ramdisk.cpio.gz \
  --add /lib/hanoip-display/msm.ko=work/hanoip-touch-20261024/handoff-unbooted/msm.ko

python3 scripts/hanoip_boot.py repack \
  work/hanoip-touch-20261024/kernel-hanoip-touch.img \
  work/hanoip-touch-20261024/handoff-unbooted/ramdisk.cpio.gz \
  work/hanoip-touch-20261024/handoff-unbooted/kernel-hanoip-touch-handoff.img \
  --kernel work/hanoip-touch-20261024/Image.gz \
  --dtb work/hanoip-touch-20261024/handoff-unbooted/kernel.dtb

python3 scripts/hanoip_boot.py uboot \
  work/baseline-before-qup-2026-10-24/u-boot-hanoip-boot.img \
  work/hanoip-touch-20261024/handoff-unbooted/u-boot.bin \
  work/hanoip-touch-20261024/handoff-unbooted/u-boot-hanoip-touch-handoff.img
```

O helper `work/hanoip-display-20261024/boot-volatile.py` aceita kernel e
`--uboot CAMINHO`. Seu default é o U-Boot do checkpoint de display, portanto
**passar explicitamente o novo U-Boot** para testar a correção do DT.
`--reset` só serve se existir o shell USB Linux; sem ele, detectar Android/fastboot.
Não usar o helper enquanto o usuário só estiver pedindo para ler este handoff.

## Ferramentas, builds e armadilhas

- Host macOS/zsh, SDK Android em PATH. Builds ARM64 por Docker/GCC 13.3.
- Containers próprios: `hanoip-mainline-build-20261024` e
  `hanoip-uboot-build-20261024`. Fontes e builds em `/tmp/kernel-mainline` e
  `/tmp/uboot-sm7150/.output`. Foram preservados; não apagar containers.
  Os dois containers foram parados ao encerrar o handoff; usar `docker start`
  somente quando for retomar builds. Os artefatos novos já foram copiados ao host.
- Outros containers `agrosync-*` são alheios. Não mexer neles.
- Checkout macOS tem colisões de nomes por maiúsculas/minúsculas em Netfilter
  e litmus. Essas modificações já existiam: não resetar nem incorporá-las.
  Builds usaram fontes extraídos via git archive no filesystem Linux e overlays.
- Não houve commit, push, PR nem publicação nesta sessão.
- Para módulos dependentes do MSM, compilar todos os targets `.ko` necessários
  numa única chamada de make. Não misturar o target DTB nessa mesma chamada:
  o kernel fez builds one-by-one e modpost perdeu símbolos entre os targets.
  Compilar DTB separadamente, depois os módulos juntos.
- Último build correto do handoff: `/tmp/hanoip-touch-handoff-build.log`.
- `python3 -m unittest discover -s tests -v`: **16 testes passaram** (10 de
  boot/CPIO, 6 de firmware). Builds kernel/U-Boot/módulos passaram. `git diff
  --check` passou antes do handoff. Isso não substitui o teste do handoff novo.
- `scripts/hanoip_validate_display.py` compara RAM/reservas/proteções com o
  checkpoint e ignora apenas renumeração de phandles nas reservas.
- RAM termina em `0x17dd00000`, nunca declarar 4 GiB cheios. Manter as 22 reservas
  fixas; não reintroduzir a reserva DFPS duplicada.
- Fix LCDB de corrupção de memória preservado: `regmap_read` recebe
  `unsigned int`, não ponteiro convertido de `u8`. Ainda há outros pontos de
  robustez/refcount do LCDB não tratados.
- Os avisos `sys_fillrect/sys_imageblit: framebuffer is not in virtual address
  space` decorrem da flag FBINFO_VIRTFB ausente no fbdev legado MSM; não foram
  corrigidos nesta etapa. Não confundir com a falha SMMU do framebuffer antigo.
- BusyBox do initramfs é Android 1.29.3. Usar `/bin/busybox APPLET` explicitamente.
  O reboot original chama setprop e não reinicia o Linux. `/sbin/reboot` é nosso
  script com guard de mounts e SysRq; pode voltar ao Android OU ao bootloader.
- Console serial: `work/hanoip-display-20261024/serial-command.py` usa host raw,
  lida com escritas parciais, salva `.raw`/`.partial.raw` e espera marcador.
  Não abrir dois leitores seriais simultâneos. Não enviar heredocs longos;
  se transferir arquivo para /tmp em RAM, conferir SHA antes de executar/carregar.
- Captura de input usada: BusyBox hexdump com `24/1 "%02x" "\n"` sobre
  `/dev/input/event3`, por 35 s. Cada evento ARM64 tem 24 bytes.
  O arquivo está em `work/hanoip-touch-20261024/input-events.txt`.

## Pendências que não devem ser esquecidas

- Correção nova do handoff compilada, ainda sem boot/validação visual.
- Usuário relatou tela preta no último teste do touch.
- Touch inicializa e firmware é verificado, mas nenhum gesto validado.
- Sem validação de suspend/resume, boot/ciclo frio de alimentações, GPU,
  120 Hz ou rootfs. Continua sendo um initramfs de diagnóstico em RAM.
- A regra de nenhuma gravação em partições continua valendo em qualquer etapa.
